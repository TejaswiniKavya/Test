package com.abc.practice;

public interface MobileProceesor {
	void process();

}
