package com.abc.demo;

public interface Vehicle {
	
	void drive();

}
