package com.abc.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
     //  Car obj=new Car();
    	ApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");
    	//Vehicle v=(Vehicle) context.getBean("Vehicle");
    	//v.drive();
    	
    	//Vehicle v=(Vehicle) context.getBean("car");
    	//Vehicle v=(Vehicle) context.getBean("bike");
    	//v.drive();
    	
    	//Tyre t=(Tyre) context.getBean("tyre");
    	Vehicle v=(Vehicle) context.getBean("car");
    	v.drive();
    	//System.out.println(t);
    }
} 
